//
//  ViewController.swift
//  iOS
//
//  Created by Kaishan Patel on 21/09/2018.
//  Copyright © 2018 Kaishan Patel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    let disposeBag = DisposeBag()
    
    @IBOutlet weak var myTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let matchesNib = UINib(nibName: "myCell", bundle: nil)
        myTableView.register(matchesNib, forCellReuseIdentifier: ")
    }


}

